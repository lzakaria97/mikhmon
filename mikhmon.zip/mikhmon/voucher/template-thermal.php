                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    <?php
/*
 1 lembar A4 total 14 voucher scale 100  
  1 lembar A4 total 60 voucher scale 50
*/

if(substr($validity,-1) == "d"){
$validity = "<i>Masa Aktif</br>".substr($validity,0,-1)." Hari</i>";
}else if(substr($validity,-1) == "h"){
$validity = "Masa Aktif".substr($validity,0,-1)." Jam";}
/*if($getsprice == "3000"){ $color = "#01579B";} 
elseif($getsprice == "1000"){ $color = "#FF1493";} pink
elseif($getsprice == "2000"){ $color = "#8B008B";}
elseif($getsprice == "3000"){ $color = "#01579B";}
elseif($getsprice == "5000"){ $color = "#800000";}
elseif($getsprice == "10000"){ $color = "#FF1493";}
elseif($getsprice == "15000"){ $color = "#228B22";} ijo
elseif($getsprice == "20000"){ $color = "#008000";} ijo
elseif($getsprice == "30000"){ $color = "#FF00FF";}
elseif($getsprice == "60000"){ $color = "#E60C00";} ---
elseif($getsprice == "75000"){ $color = "#FF0000";}  
elseif($getsprice == "70000"){ $color = "#CF0000";} 
else{ $color = "#BA68C8";}*/
if($profile == "1-Hari"){ $color = "#FFFFFF";} 
elseif($profile == "7-Hari"){ $color = "#FFFFFF";}  
elseif($profile == "30-Hari"){ $color = "#FFFFFF";} 
else{ $color = "#FFFFFF";}
?>
<style type="text/css">.rotate {
vertical-align: center;
text-align: center;
font-size: 12px;}.rotate span {
-ms-writing-mode: tb-rl;
-webkit-writing-mode: vertical-rl;
writing-mode: vertical-rl;
transform: rotate(180deg);
white-space: nowrap;}
.qrcode{
    height:100px;
    width:100px;
    border: 2px solid black;
}
</style>
<!--mks-mulai-->
<!--mks-border-mulai-->
<table class="voucher" style="border: 2px solid <?php echo "#000000";?>;width:220px;">
<!--mks-border-akhir--> 
<!--mks-price-->
<tbody>
<tr>
<td style="font-weight: bold; border-right: 2px solid black; color:#000;background-color:<?php echo $color;?>; -webkit-print-color-adjust: exact;" class="rotate" rowspan="5"><span><?php echo $price;?></span></td>
<td style="font-weight: bold; border-left: 2px solid black; color:#000;background-color:<?php echo $color;?>; -webkit-print-color-adjust: exact;" class="rotate" rowspan="5"><span></span></td>  
<!--mks-price-akhir-->  
<!--mks-logo--> 
<td style="font-size: 9.5px;font-weight:normal;"><?php echo $validity;?></td>
<td style="font-weight: bold" colspan="1" ><img src="<?php echo $logo;?>" alt="logo" style="height:23px;"></td>
<!--mks-logo-akhir--> 
<!--mks-voucher-->  
<tr><td style="font-size: 10px;font-weight:bold; border-top:1px black solid;border-bottom:1px black solid" colspan="3"><center>.: Login: <?php echo $dnsname;?> :.</center></td></tr>

<?php if($usermode == "vc"){?> 
<tr>
<td style="width: 100%; font-weight: bold; font-size: 18px; color:#111; text-align: center;" colspan="2"><?php echo $username;?></td></tr>
<?php }elseif($usermode == "up"){?>
<tr style=" text-align: center;font-size: 12px;">
          <td style="width: 50%">Username</td>
          <td style="width: 50%">Password</td>
        </tr>
        <tr style="font-size: 18px;text-align: center;">
          <td style="border: 1px solid black; font-weight:bold;"><?php echo $username;?></td>
          <td style="border: 1px solid black; font-weight:bold;"><?php echo $password;?></td>
        </tr>
<?php }?> 
<!--mks-voucher-akhir-->
<!--mks-limitasi-mulai--> 

<!--mks-limitasi-akhir-->
<!--mks-cs-mulai--> 
<tr style="width:100%;">
<td colspan="5" style="font-size: 10px;">
<i>WA : 08976497111</i>    
      <?php
      //echo $comment;
      $bln = substr($comment,7,2);
      $tgl = substr($comment,10,2);
      $thn = substr($comment,13,2);
      echo $tgl."-".$bln."-".$thn;
      ?>
</td>
</tr>
</tr>
</tbody>
</table> 
<!--mks-cs-akhir-->
<!--mks-selesai-->                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            