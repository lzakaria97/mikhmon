<?php 
if(substr($_SERVER["REQUEST_URI"], -10) == "config.php"){header("Location:./");}; 
$data['mikhmon'] = array ('1'=>'mikhmon<|<admin','mikhmon>|>mZWfoZ8=');

$data['wifirt03'] = array ('1'=>'wifirt03!10.246.237.12:7789','wifirt03@|@lutfi','wifirt03#|#mp2TrWNiaWo=','wifirt03%WiFi RT03','wifirt03^hotspot.rt3.net','wifirt03&Rp','wifirt03*10','wifirt03(1','wifirt03)','wifirt03=10','wifirt03@!@enable');